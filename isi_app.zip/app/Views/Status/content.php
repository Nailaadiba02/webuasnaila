<?php
echo $this->extend('template/index');
echo $this->section('content');
?>
<p>content Status</p>
<?php
echo $this->endsection();